<?php


namespace App\Models;


class Firewall
{

    private $nextRequest = false;

    private $ip;

    private $whiteList;

    public function __construct()
    {
        $this->ip = $this->getIP();
        $this->saveRequest();



        $whitelistFile = fopen(__DIR__ . '/../files/whitelist.txt', "r");

        $this->whiteList = explode(',', fread($whitelistFile,filesize(__DIR__ . '/../files/whitelist.txt')));

        fclose($whitelistFile);

        var_dump($this->whiteList);

        die();

    }

    public function next()
    {
        return array_search($this->ip, $this->whiteList);
    }

    private function getIP()
    {
        return $_SERVER['REMOTE_ADDR'];
    }

    private function saveRequest()
    {
        if(!isset($_SESSION[$this->ip]))
            $_SESSION[$this->ip] = [1, time()];
        else
            $this->checkMaxRequestBySecond();
    }

    private function checkMaxRequestBySecond()
    {
        $interval = 1; // segundos
        $maxRequests = 5; // requests
        $fastRequest = ($_SESSION[$this->ip][1] > time() - $interval);

        if($fastRequest && $_SESSION[$this->ip][0] < $maxRequests)
            $_SESSION[$this->ip][0]++;
        elseif ($fastRequest) {
            require __DIR__ .'/../views/error.phtml';
            die();
        }
        else
            $_SESSION[$this->ip] = [1, time()];

    }


    private function getRealIP()
    {
        if (!empty($_SERVER['HTTP_CLIENT_IP']))
            return $_SERVER['HTTP_CLIENT_IP'];

        //whether ip is from proxy
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
            return $_SERVER['HTTP_X_FORWARDED_FOR'];

        //whether ip is from remote address
        return $_SERVER['REMOTE_ADDR'];

    }
}